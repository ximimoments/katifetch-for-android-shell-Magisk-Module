#!/system/bin/sh

ui_print " "
ui_print "╔══════════════════════╗"
ui_print "║     KATIFETCH        ║"
ui_print "║     by kati dev      ║"
ui_print "╚══════════════════════╝"
ui_print " "

ui_print "📱 Device: $(getprop ro.product.model)"
ui_print "🤖 Android: $(getprop ro.build.version.release)"

ui_print "Installing Katifetch..."
ui_print " "

# IMPORTANTE: permisos
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/katifetch 0 0 0755
